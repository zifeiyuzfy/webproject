# webproject

纯前端实现的Web课程教学辅助系统，包含首页，账户，提交问题，发布问题等模块。

打开login.html即可自动加载indexDB数据库，默认账户老师userId为1，学生userId为2，密码默认和userId相同，输入账户密码点击登录即可进入首页。
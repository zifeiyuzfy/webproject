// var userData = {
//   userId: localStorage.getItem("userId"),
//   password: localStorage.getItem("password"), //密码
//   type: "guest",
//   name: "Guest", //昵称
//   disable: false,
//   isAllowRegister: true,
//   autograph: "奋发进取", //签名档
//   pendingdeal: "",
//   avatar: "",
// };
// //初始化个人信息
// function initializeUserDetail() {
//   //从数据库获取当前个人信息
//   openDB("OJSystemDB", 1).then(function (db) {
//     window.db = db;
//     //查找我的数据
//     getDataByKey(db, "user", userData.userId)
//       .then(function (myData) {
//         if (myData !== false) {
//           userData = myData;
//           // 设置昵称、密码、签名档、个人待办事项的默认值
//           document.getElementById("nickname").value = userData.name;
//           document.getElementById("password").value = userData.password;
//           document.getElementById("signature").value = userData.autograph;
//           document.getElementById("todo").value = userData.pendingdeal;
//         }
//       })
//       .catch(function (error) {
//         console.error(error);
//       });
//   });
// }

// //保存信息
// document.addEventListener("DOMContentLoaded", function () {
//   document.getElementById("saveProfile").addEventListener("click", function () {
//     // 获取输入框的值
//     var nickname = document.getElementById("nickname").value;
//     var password = document.getElementById("password").value;
//     var signature = document.getElementById("signature").value;
//     var pendingdeal = document.getElementById("todo").value;
//     const currentUserID = localStorage.getItem("userId");

//     // 更新数据库中的用户信息
//     openDB("OJSystemDB", 1).then(function (db) {
//       db = db;
//       //查找我的数据
//       getDataByKey(db, "user", currentUserID)
//         .then(function (element) {
//           let updateData = {
//             userId: element.userId,
//             password: sha256Encrypt(password),
//             type: element.type,
//             name: nickname,
//             disable: element.disable,
//             isAllowRegister: element.isAllowRegister,
//             autograph: signature,
//             pendingdeal: pendingdeal,
//             avatar: userData.avatar,
//           };
//           localStorage.setItem("password", password);
//           updateDB(db, "user", updateData)
//             .then(function (updateResult) {
//               console.log("updateResult为：" + updateResult);
//               if (updateResult === true) {
//                 swal("保存成功", "", "success");
//                 userData.name = nickname;
//                 userData.password = password;
//                 userData.autograph = signature;
//                 userData.pendingdeal = pendingdeal;
//                 userData.avatar = userData.avatar;
//               } else {
//                 swal("保存失败", "", "error");
//               }
//             })
//             .catch(function (error) {
//               console.error(error);
//             });
//         })
//         .catch(function (error) {
//           console.error(error);
//         });
//     });
//   });
// });
